#################################
#PLEASE DO NOT REMOVE THIS FILE!#
#################################
import es
import psyco
psyco.full()
es.dbgmsg(0, "[eXtendable Admin] Module folder enabled")

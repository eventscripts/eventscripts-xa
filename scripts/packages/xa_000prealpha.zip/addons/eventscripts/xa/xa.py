import es
import popup
import keymenu
import playerlib
import entitylib
from es import server_var
from popup import popup
from keymenu import keymenu
from playerlib import playerlib
from entitylib import entitylib

# *************************
# TODO list at end of file
# *************************

#plugin information
info = {}
info['name'] = "eXtendable Admin EventScripts Python addon"
info['version'] = ""
info['author'] = "EventScripts Developers"
info['url'] = ""
info['description'] = ""
info['tags'] = ""

#global variables:
## gModules holds all the modules
gModules = {}
## gCommands holds all the commands
gCommands = {}
## gMenus holds all the menus
gMenus = {}


# Admin_module is the module class
class Admin_module:
    def __init__(self, gModule):
        #initialization of the module
        self.name = gModule
        self.loaded = 1
        self.requiredcount = 0
        self.requiredby = []
        self.requiredlist = []
        try:
            es.load("xa/modules/"+self.name)
        except:
            self.loaded = 0
    def load(self)
        if self.loaded == 0:
            try:
                es.load("xa/modules/"+self.name)
            except:
                self.loaded = 0
                return False
            return True
        return False
    def unload(self):
        if self.loaded == 1 and self.requiredcount == 0:
            try:
                es.unload("xa/modules/"+self.name)
                for module in self.requiredlist:
                    if module in gModules:
                        m = gModules[module]
                        m.requiredby.remove(self.name)
                        m.requiredcount -= 1
                        self.requiredlist.remove(m.name)
            except:
                self.loaded = 1
                return False
            return True
        return False
    def delete(self):
        delete(self.name)
    def requires(self, gModuleList):
        fails = []
        modules = list(gModuleList)
        for module in modules:
            if module in gModules:
                m = gModules[module]
                m.requiredby.append(self.name)
                m.requiredcount += 1
                self.requiredlist.append(m.name)
            else:
                fails.append(module)
        if len(fails) > 0:
            return fails
        else:
            return True
    def unrequires(self, gModuleList):
        fails = []
        modules = list(gModuleList)
        for module in modules:
            if module in self.requiredlist:
                m = gModules[module]
                m.requiredby.remove(self.name)
                m.requiredcount += 1
                self.requiredlist.remove(m.name)
            else:
                fails.append(module)
        if len(fails) > 0:
            return fails
        else:
            return True

# Admin_command is the clientcmd class
class Admin_command:
    def __init__(self, gModule, gCommand, gBlock, gPerm, gPermLevel, gTarget=False):
        #initialization of the module
        self.name = gCommand
        self.module = gModule
        self.block = gBlock
        self.permission = gPerm
        self.permissionlevel = gPermLevel
        self.target = gTarget
        self.server = False
        self.console = False
        self.say = False
    def create(self, gList)
        cmdlist = list(gList)
        if "server" in cmdlist and self.server == False:
            es.regcmd(self.name, "xa/incoming_server", "eXtendable Admin command")
            self.server = True
        if "console" in cmdlist and self.console == False:
            es.server.cmd("clientcmd create console "+str(self.name)+" xa/incoming_console "+str(self.permission)+" "+str(self.permissionlevel))
            self.console = True
        if "say" in cmdlist and self.say == False:
            es.server.cmd("clientcmd create say "+str(self.name)+" xa/incoming_say "+str(self.permission)+" "+str(self.permissionlevel))
            self.say = True
    def delete(self, gList)
        cmdlist = list(gList)
        if "console" in cmdlist and self.console == True:
            es.server.cmd("clientcmd delete console "+str(self.name)+" xa/incoming_console "+str(self.permission)+" "+str(self.permissionlevel))
            self.console = False
        if "say" in cmdlist and self.say == True:
            es.server.cmd("clientcmd delete say "+str(self.name)+" xa/incoming_say "+str(self.permission)+" "+str(self.permissionlevel))
            self.say = False
            
# Admin_menu is the clientcmd class
class Admin_menu:
    def __init__(self, gModule, gMenu):
        #initialization of the module
        self.name = gMenu
        self.module = gModule
        # TODO:
        # - Add the menu management system
        #   * clientcmd like permissions for menus
        #   * needs to auto support player- and weaponlist menus with popup.easymenu
        #   * needs to have a main menu level with submenus
        #   * ...

#basic commands begin here
#usage from other Python scripts for example:
#
# TODO:
# - Add all the module and command wrappers for the classes
# - The "incoming" functions for clientcmd's and servercmd's needs to be done (see the Admin_command class)
#
# The classes are hidden to the outer world. All other python modules use functions that are specified below!
